<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Fornecedor extends Model
{
    protected $guarded=[];
    protected $fillable = [
        'nome',
        'email',
        'telefone',
        'cpf'
    ];
}
