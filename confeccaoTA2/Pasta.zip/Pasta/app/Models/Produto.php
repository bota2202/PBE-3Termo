<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produto extends Model
{
    protected $guarded=[];
    protected $fillable = [
        'nome',
        'preco',
        'estoque'
    ];
}
