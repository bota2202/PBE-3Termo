<nav x-data="{ open: false }"
     class="fixed top-0 left-0 w-full z-50 bg-white border-b border-gray-100">

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">

            <!-- ESQUERDA -->
            <div class="flex">
                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('dashboard') }}">
                        <x-application-logo class="block h-9 w-auto fill-current text-gray-800" />
                    </a>
                </div>

                <!-- LINKS DESKTOP -->
                <div class="hidden space-x-8 sm:-my-px sm:ms-10 sm:flex">

                    <x-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                        Dashboard
                    </x-nav-link>

                    <x-nav-link :href="route('clientes.index')" :active="request()->routeIs('clientes.*')">
                        Clientes
                    </x-nav-link>

                    <x-nav-link :href="route('produtos.index')" :active="request()->routeIs('produtos.*')">
                        Produtos
                    </x-nav-link>

                    <x-nav-link :href="route('estoque.index')" :active="request()->routeIs('estoque.*')">
                        Estoque
                    </x-nav-link>

                    <x-nav-link :href="route('fornecedores.index')" :active="request()->routeIs('fornecedores.*')">
                        Fornecedores
                    </x-nav-link>

                    <x-nav-link :href="route('pedidos.index')" :active="request()->routeIs('pedidos.*')">
                        Pedidos
                    </x-nav-link>

                </div>
            </div>

            <!-- DIREITA -->
            <div class="hidden sm:flex sm:items-center sm:ms-6">
                <x-dropdown align="right" width="48">

                    <x-slot name="trigger">
                        <button class="inline-flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 bg-white hover:text-gray-800 transition">

                            @auth
                                <div>{{ Auth::user()->name }}</div>
                            @else
                                <div>Convidado</div>
                            @endauth

                            <div class="ms-1">
                                <svg class="fill-current h-4 w-4" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd"
                                        d="M5.293 7.293a1 1 0 011.414 0L10
                                           10.586l3.293-3.293a1 1 0
                                           111.414 1.414l-4 4a1 1 0
                                           01-1.414 0l-4-4a1 1 0
                                           010-1.414z"
                                        clip-rule="evenodd" />
                                </svg>
                            </div>

                        </button>
                    </x-slot>

                    <x-slot name="content">
                        @auth
                            <x-dropdown-link :href="route('profile.edit')">
                                Profile
                            </x-dropdown-link>

                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <x-dropdown-link :href="route('logout')"
                                    onclick="event.preventDefault();
                                    this.closest('form').submit();">
                                    Log Out
                                </x-dropdown-link>
                            </form>
                        @endauth
                    </x-slot>

                </x-dropdown>
            </div>

            <!-- MOBILE BUTTON -->
            <div class="-me-2 flex items-center sm:hidden">
                <button @click="open = ! open"
                    class="p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition">
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path :class="{'hidden': open, 'inline-flex': !open }"
                            class="inline-flex"
                            stroke-linecap="round" stroke-linejoin="round"
                            stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': !open, 'inline-flex': open }"
                            class="hidden"
                            stroke-linecap="round" stroke-linejoin="round"
                            stroke-width="2"
                            d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

        </div>
    </div>

    <!-- MOBILE MENU -->
    <div :class="{'block': open, 'hidden': ! open}" class="hidden sm:hidden bg-white border-t">

        <div class="pt-2 pb-3 space-y-1">

            <x-responsive-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                Dashboard
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('clientes.index')" :active="request()->routeIs('clientes.*')">
                Clientes
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('produtos.index')" :active="request()->routeIs('produtos.*')">
                Produtos
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('estoque.index')" :active="request()->routeIs('estoque.*')">
                Estoque
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('fornecedores.index')" :active="request()->routeIs('fornecedores.*')">
                Fornecedores
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('pedidos.index')" :active="request()->routeIs('pedidos.*')">
                Pedidos
            </x-responsive-nav-link>

        </div>

        <div class="pt-4 pb-1 border-t border-gray-200 px-4">
            @auth
                <div class="font-medium text-base text-gray-800">
                    {{ Auth::user()->name }}
                </div>
                <div class="font-medium text-sm text-gray-500">
                    {{ Auth::user()->email }}
                </div>
            @endauth
        </div>

    </div>
</nav>